# HAP 单机版（nocoly）

nocoly HAP 单机版，五组件：**app**（微服务）、**sc**（内置全部存储：MySQL/MongoDB/Redis/Kafka/ES/MinIO）、**command**（代码块执行）、**doc**（文档预览）、**flink**（数据集成，可关）。

安装后通过 `ENV_ADDRESS_MAIN` 指定的地址访问（默认 NodePort 30880）。请务必：
- 把 `主访问地址` 改成你实际用浏览器访问的 URL（含端口），否则图标/工作流页面会异常；
- 重置 `API Token`；
- 确认数据盘容量（sc 内置存储较占空间）。
