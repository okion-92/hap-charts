# HAP 单机版 (nocoly) · Helm Chart

nocoly HAP（超级应用平台）单机版，打包为单副本 Helm Chart，可在 Rancher Apps & Marketplace / 任意 Kubernetes 集群一键安装。

## 组件（5）

| 组件 | 说明 | 端口 |
| --- | --- | --- |
| **app** | 微服务（HAP 平台主体） | 8880（NodePort 对外） |
| **sc** | 内置全部存储：MySQL / MongoDB / Redis / Kafka / ZooKeeper / Elasticsearch / MinIO / File | 内部 |
| **command** | 代码块执行 | 内部 |
| **doc** | 文档预览 | 内部 |
| **flink** | 数据集成（可关，`flink.enabled=false`） | 8081 |

组件间按 Service 名互访（headless Service + `publishNotReadyAddresses`，保证 sc 内 MinIO 启动时可解析自身）。

## 前置

- Kubernetes ≥ 1.23；提供默认 StorageClass（如 k3s `local-path`）。
- 可访问镜像仓库 `nocoly`（公有，无需 pull secret）。
- 单机生产建议 ≥ 8C / 48G / SSD（最小测试 8C/32G）。

## 安装

Rancher：Apps → Charts → 「HAP 单机版 (nocoly)」→ Install。
或 Helm：
```bash
helm install hap ./hap-nocoly-single -n hap --create-namespace \
  --set hap.addressMain=http://<访问IP或域名>:<端口> \
  --set persistence.storageClass=local-path
```

## 必填参数

| 参数 | 说明 |
| --- | --- |
| `hap.addressMain` | **必填**。浏览器访问地址（含端口），须与实际访问一致，否则图标/工作流页面异常。 |
| `persistence.storageClass` | **必填**。PVC 使用的 StorageClass（单节点 k3s 填 `local-path`）。 |

## 主要参数

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `hap.nodePort` | `30880` | app 8880 对外的 NodePort |
| `hap.captainEndpoint` | `http://172.17.0.4:38880` | captain/管理器端点（部署在指定 VM/物理机上的外部服务，按实际填） |
| `hap.appVersion` / `images.*` | 7.3.5 等 | 各组件镜像 tag |
| `flink.enabled` | `true` | 是否启用 Flink |
| `persistence.sharedDataSize` | `30Gi` | 共享数据卷（核心数据：DB/对象存储/索引），挂 `/data` |
| `persistence.hapDataSize` | `10Gi` | app 数据卷，挂 `/data/hap/data` |
| `resources.<组件>` | requests | 仅设 requests，不设 limits（单机共享内存，避免误杀） |

## 存储

- `hap-shared-data` → `/data`（app/sc/flink 共享，**全部数据库 + 对象存储 + 索引**）。
- `hap-data` → `/data/hap/data`（app）。
- 单节点 RWO；备份/迁移主要关注 `hap-shared-data`。

## 凭据

不内置真实凭据。`ENV_API_TOKEN` 走 Secret，密码类首启/交付时设置并加密保管。

## 访问

安装后通过 `hap.addressMain`（默认 NodePort `http://<节点IP>:30880`）访问，完成首次初始化。

## 备注

- 配置经 ConfigMap，pod 模板带 configmap/secret checksum 注解 → 改配置 `helm upgrade` 会自动滚动重启 app/sc。
- captain / server ID 依赖外部 captain 服务可达，不在本 chart 范围。
